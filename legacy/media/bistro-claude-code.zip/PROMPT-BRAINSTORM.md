# Prompt para `/superpowers:brainstorm`

Copia todo lo que está bajo la línea y pégalo después del comando en Claude Code.

---

Quiero rediseñar y reconstruir la web de Bistró (bistrochile.com), catering corporativo en Santiago, y sumar una página de propuesta para el cliente. Antes de escribir código necesito un plan de diseño e implementación.

## Contexto que tienes que leer primero

1. `CLAUDE.md` en la raíz del repo: objetivo, problema de negocio, marca (tokens, tipografía, reglas de color), dirección estética, estructura de cada pantalla, reglas de conversión, datos reales y pendientes. Es la fuente de verdad del contenido y la marca.
2. `docs/wireframes/`: wireframes de baja fidelidad (HTML en grises) de todas las pantallas. Fuente de verdad del layout y el comportamiento, no del estilo. Lienzo interactivo: https://claude.ai/artifact/BVgQpaMK1P5fNDU3geRPat
   - Mobile: `Hero-B`, `Servicios`, `Como-funciona`, `Resenas`, `Preguntas`, `Cierre`, `Barra-fija`.
   - Formulario: paso 1 dentro de `Hero-B`, `Form-paso-2`, `Confirmacion`.
   - Propuesta: `Propuesta`, `Reservar`.
   - Escritorio: `Landing-desktop`.
   - `Main` es el hero A, descartado: no usarlo.
3. El código actual del repo: qué se puede reutilizar (GA4, WhatsApp, schema.org, envío del formulario) y qué se reemplaza.

## El problema que tiene que resolver el diseño

Llegan varias solicitudes de cotización desde la web, pero se cierran pocas. Por eso:
- La landing **precalifica**: requisitos a la vista y un aviso en vivo en el paso 1 del formulario (mínimo 20 personas, 7 días de anticipación, 3 semanas para más de 100 personas). No se publican precios: dependen de cada evento.
- Se pide un **presupuesto aproximado opcional** (por persona o total) para que la propuesta calce desde el primer envío.
- La **página de propuesta** reemplaza el PDF de Canva: se genera desde Airtable, muestra 3 opciones con una recomendada, deja reservar y pagar el 50% con Webpay o transferencia, y registra si el cliente la vio y qué opción eligió, para hacer seguimiento.

## Principios de estética (cookbook de Anthropic "Prompting for frontend aesthetics")

- Tipografía con carácter: Fraunces (display) e Instrument Sans (cuerpo), con contrastes fuertes de peso y tamaño entre titulares y texto. Nada de Inter, Roboto, Arial ni fuentes del sistema.
- Un tema coherente y fijo, todo con variables CSS: los colores históricos de Bistró (negro y amarillo) más crema de fondo. Negro dominante, amarillo escaso y solo para la acción, y nunca texto amarillo sobre fondos claros.
- Movimiento: un solo momento bien orquestado (la entrada del hero con revelado escalonado vía `animation-delay`) y micro-interacciones discretas. Respetar `prefers-reduced-motion`.
- Fondos con atmósfera, no planos: grano de papel sutil y alternancia crema → hueso → negro.
- Evitar los clichés de diseño hecho con IA: layouts genéricos, gradientes morados, glassmorphism, tarjetas iguales con ícono. Ojo: negro + amarillo mal usado parece señalética o comida rápida; para que se vea premium, amarillo cálido y escaso, mucho crema, fotos reales grandes y Fraunces en los titulares.

## Restricciones

- Next.js (App Router) + TypeScript + Tailwind, deploy en Vercel.
- Mobile first (375 px), LCP < 2,5 s en 4G, accesibilidad AA.
- Nunca inventar datos: lo que falta va como `TODO:` visible (lista de pendientes en `CLAUDE.md`).
- Secretos (Airtable, Flow/Webpay) solo en el servidor.

## Qué espero del brainstorm

Hazme las preguntas que necesites, una a la vez. Temas que sé que hay que decidir:
- Fases: propongo (1) landing + formulario + Airtable, (2) propuesta + reserva + pago, (3) automatizaciones de seguimiento. ¿Tiene sentido ese orden?
- Flow o Webpay Plus directo.
- Modelo de datos en Airtable: tablas Solicitudes y Propuestas, y cómo Carolina arma una propuesta sin tocar código.
- Cómo se identifica una propuesta en la URL sin que se puedan adivinar las de otros clientes.
- Qué se reutiliza del repo actual.

Al final quiero un plan de diseño escrito (sistema de diseño en Tailwind, componentes, pantallas, datos, integraciones y fases) que después le voy a pasar a `/frontend-design:frontend-design` junto con los wireframes.
